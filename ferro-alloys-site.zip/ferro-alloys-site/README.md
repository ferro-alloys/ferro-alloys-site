# Ferro-Alloys.com Website Prototype

This is a ready-to-edit Next.js + Tailwind front-end prototype for Ferro-Alloys.com.

## What is included
- Homepage
- Market Prices page
- News & Reports page
- Buy & Sell Marketplace
- Company Directory
- Conference & Events
- Membership & Pricing
- AI Assistant
- CRM Dashboard
- Contact page
- About page
- Admin Dashboard

## How to run locally
1. Install Node.js
2. Open this folder in Cursor or VS Code
3. Run:
   npm install
   npm run dev
4. Open http://localhost:3000

## How to deploy
Recommended: Vercel
1. Create a Vercel account
2. Upload/import this project
3. Click Deploy

## Next development steps
- Connect Supabase for database/login
- Connect OpenAI API for AI assistant
- Add Stripe/PayPal/Alipay/WeChat Pay payment options
- Add real price/news/company data
- Connect email/CRM tools
