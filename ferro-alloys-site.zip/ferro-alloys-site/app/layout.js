import './globals.css'

export const metadata = {
  title: 'Ferro-Alloys.com - AI Ferro-Alloys Market Platform',
  description: 'AI-powered global ferro-alloys market intelligence, trading, CRM, and conference platform.'
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
